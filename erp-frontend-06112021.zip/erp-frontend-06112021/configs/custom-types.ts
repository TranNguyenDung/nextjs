export interface IProduct {
  name: string;
  images: string[];
  customerPrice: number;
}
