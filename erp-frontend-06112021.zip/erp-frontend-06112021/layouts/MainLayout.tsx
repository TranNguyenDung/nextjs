import { useRouter } from "next/router";
import React, { FC } from "react";
import Image from "next/image";
import classnames from "classnames";

import styles from "./MainLayout.module.scss";

interface IProps {}

const MainLayout: FC<IProps> = ({ children }) => {
  const router = useRouter();

  return (
    <div className={styles.mainLayout}>
      <div
        className={classnames(styles.header, {
          [styles.contact]: router.asPath === "/contact",
        })}
      >
        <div className={styles.logo}>
          <Image
            src="https://www.stdio.vn/static/logo.svg"
            width={32}
            height={32}
            alt="STDIO logo"
            unoptimized={true}
          />
        </div>
      </div>
      <div className={styles.main}>{children}</div>
      <div className={styles.footer}>Footer</div>
    </div>
  );
};

export default MainLayout;
