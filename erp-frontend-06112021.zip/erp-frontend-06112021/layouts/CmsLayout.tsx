import React, { FC } from "react";
import styles from "./CmsLayout.module.scss";

// const CmsLayout = ({ header, sidebar, children }) => {
//   return (
//     <div className={styles.cmsLayout}>
//       <div className={styles.header}>{header}</div>
//       <div className={styles.sidebar}>{sidebar}</div>
//       <div className={styles.main}>{children}</div>
//     </div>
//   );
// };

interface IProps {
  main: React.ReactNode;
}

const CmsLayout: FC<IProps> = ({ main }) => {
  return (
    <div className={styles.cmsLayout}>
      <div className={styles.header}>
        <div className={styles.left}>
          <div className={styles.logo}></div>
        </div>
        <div className={styles.right}>Sign out</div>
      </div>
      <div className={styles.sidebar}></div>
      <div className={styles.main}>{main}</div>
    </div>
  );
};

export default CmsLayout;
