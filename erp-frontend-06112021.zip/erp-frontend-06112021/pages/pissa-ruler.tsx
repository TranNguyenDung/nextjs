import { useEffect } from "react";
import { NextPage } from "next";
import MainLayout from "../layouts/MainLayout";
import axios from "axios";

import styles from "./pissa-ruler.module.scss";

interface IProps {}

const PissaRuler: NextPage<IProps> = () => {
  useEffect(() => {
    axios
      .get(
        "https://api-v2.vphone24h.vn/products?filter=%7B%22branch%22:%2260f32e78b8199a76a4ba9ee6%22%7D"
      )
      .then((resp) => {
        console.log(resp.data);
      })
      .catch((err) => {});
  }, []);

  return (
    <MainLayout>
      <div className={styles.pissaRuler}>
        <div className={styles.banner}></div>
        <div className={styles.features}></div>
      </div>
    </MainLayout>
  );
};

export default PissaRuler;
