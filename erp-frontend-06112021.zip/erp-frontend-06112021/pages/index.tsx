import Head from "next/head";
import Image from "next/image";
import Flag from "react-world-flags";
import { Gi3DGlasses, GiAbstract061 } from "react-icons/gi";
import { FiCoffee } from "react-icons/fi";
import { evaluate } from "mathjs";
import { GetServerSideProps, NextPage } from "next";
import Cookies from "js-cookie";
var ServerCookies = require("cookies");
import { get } from "lodash";

import MainLayout from "../layouts/MainLayout";

import styles from "./index.module.scss";
import { useDispatch, useSelector } from "react-redux";
import { AppState } from "../redux/store";
import Test from "../components/Test";
import { mySlice } from "../redux/mySlice";

interface IProps {}

const Index: NextPage<IProps> = () => {
  const me = useSelector((state: AppState) => state.me);
  const dispatch = useDispatch();

  return (
    <MainLayout>
      <div className={styles.index}>
        <Test />

        {me}

        <button
          onClick={() => {
            dispatch(mySlice.actions.update(123));
          }}
        >
          Change my state
        </button>
        <button
          onClick={() => {
            Cookies.set(
              "token",
              JSON.stringify({
                username: "vinh.lakien@stdio.vn",
                password: "123456",
              })
            );
          }}
        >
          Set cookie
        </button>
        <button
          onClick={() => {
            localStorage.setItem("gameHp", "12345");
            console.log(localStorage.getItem("gameHp"));
          }}
        >
          Set localStorage
        </button>
        <Flag code="704" height="32" />
        <button>
          <Gi3DGlasses color="#f00" size={32} /> Press me
        </button>
        <GiAbstract061 color="#f00" size={32} />
        <FiCoffee color="#f0f" size={50} />
        {evaluate("3 + 2 *(6+1)")}
      </div>
    </MainLayout>
  );
};

export const getServerSideProps: GetServerSideProps = async (context) => {
  const cookies = new ServerCookies(context.req, context.res);

  cookies.set("token", "xyz");

  // context.res.setHeader("set-cookie", ["token=3933938"]);

  return {
    props: {}, // will be passed to the page component as props
  };
};

export default Index;
