import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { NextPage } from "next";
import axios from "axios";
import { get } from "lodash";

import MainLayout from "../layouts/MainLayout";
import ProductItem from "../components/ProductItem";
import { IProduct } from "../configs/custom-types";

import styles from "./products.module.scss";

interface IProps {}

const Products: NextPage<IProps> = () => {
  const [products, setProducts] = useState<IProduct[]>([]);

  useEffect(() => {
    axios
      .get(
        "https://api-v2.vphone24h.vn/products?filter=%7B%22branch%22:%2260f32e78b8199a76a4ba9ee6%22%7D"
      )
      .then((resp) => {
        console.log(resp);
        setProducts(resp.data.items);
      })
      .catch((err) => {});
  }, []);

  return (
    <div className={styles.products}>
      <button
        onClick={() => {
          axios
            .get(
              "https://google.com/prods?filter=%7B%22branch%22:%2260f32e78b8199a76a4ba9ee6%22%7D"
            )
            .then((resp) => {
              console.log(resp);
              setProducts(resp.data.items);
            })
            .catch((err) => {
              console.log(err);
            });
        }}
      >
        Get products
      </button>
      {/* {products.length > 0 && (
        <ProductItem
          name={products[0].name}
          price={products[0].customerPrice}
          thumbnail={products[0].images[0]}
        />
      )} */}

      {/* {!!products[0] ? <ProductItem product={products[0]} /> : null} */}
      {!!products && products.length > 0 && (
        <ProductItem product={products[0]} />
      )}

      {!!products && products.length > 0 ? (
        <ProductItem product={products[0]} />
      ) : (
        <h2>Nothing</h2>
      )}

      {/* <ProductItem
        name={get(products, "[0].name", "")}
        price={get(products, "[0].customerPrice", 0)}
        thumbnail={get(products, "[0].images[0]", "")}
      /> */}

      {/* <ProductItem product={products[0]} /> */}

      {products.map((product, i) => (
        <ProductItem product={product} key={i} />
      ))}

      {products.map(
        (product, i) => i < 3 && <ProductItem product={product} key={i} />
      )}

      {products.map((product, i) => {
        return <ProductItem product={product} key={i} />;
      })}
    </div>
  );
};

export default Products;
