import { NextPage } from "next";
import MainLayout from "../layouts/MainLayout";

import styles from "./contact.module.scss";

interface IProps {}

const Contact: NextPage<IProps> = () => {
  return (
    <MainLayout>
      <div className={styles.contact}>
        <div className={styles.logo}>Logo</div>
        <div className={styles.button}>Press Me</div>
      </div>
    </MainLayout>
  );
};

export default Contact;
