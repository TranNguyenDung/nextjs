import { NextPage } from "next";

import CmsLayout from "../../../layouts/CmsLayout";

import styles from "./index.module.scss";

interface IProps {}

const Index: NextPage<IProps> = () => {
  return (
    <CmsLayout
      header={5}
      sidebar="xyz"
      main={<div className={styles.index}>Index Content</div>}
    ></CmsLayout>
  );
};

export default Index;
