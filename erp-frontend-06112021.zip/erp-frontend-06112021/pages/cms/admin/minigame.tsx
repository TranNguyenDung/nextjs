import { NextPage } from "next";
import CmsLayout from "../../../layouts/CmsLayout";

import styles from "./minigame.module.scss";

interface IProps {}

const Minigame: NextPage<IProps> = () => {
  return (
    <CmsLayout
      main={<div className={styles.minigame}>Minigame Content</div>}
    ></CmsLayout>
  );
};

export default Minigame;
