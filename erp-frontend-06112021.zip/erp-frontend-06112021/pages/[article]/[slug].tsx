import { useRouter } from "next/router";

const Slug = () => {
  const route = useRouter();
  console.log(route);

  return <div>App page</div>;
};

export default Slug;
