import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { number } from "mathjs";

const initialState: number = 0;

// const initialCart: any = {
//     product: IProduct;
//     quantity: number;
// }[];

export const mySlice = createSlice({
  name: "me",
  initialState, // initial state
  reducers: {
    update(state: number, action: PayloadAction<number>) {
      state = action.payload;
      return state;
    },
    // xyz(state:number, action: PayloadAction<number>) {
    //     state[0].product  = action.payload;
    // }
  }, // actions
});
