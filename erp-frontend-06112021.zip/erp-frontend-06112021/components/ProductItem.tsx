import React, { FC } from "react";
import Image from "next/image";
import { get } from "lodash";

import { IProduct } from "../configs/custom-types";

import styles from "./ProductItem.module.scss";

// interface IProps {
//   name: string;
//   price: number;
//   thumbnail: string;
// }

interface IProps {
  product?: IProduct;
}

const ProductItem: FC<IProps> = ({ product }) => {
  return (
    <div className={styles.productItem}>
      {/* <Image
        src={"https://www.vphone24.vn/" + get(product, 'images[0]', '')}
        width={128}
        height={128}
        alt={name}
      /> */}
      <h2>{get(product, "name.firstName", "")}</h2>
      <p>{get(product, "customerPrice", 0)}</p>
      <p>
        <button>Mua ngay</button>
      </p>
    </div>
  );
};

export default ProductItem;
