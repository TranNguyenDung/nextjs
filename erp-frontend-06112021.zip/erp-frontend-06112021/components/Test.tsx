import { FC } from "react";
import { useSelector } from "react-redux";

import { AppState } from "../redux/store";

interface IProps {}

const Test: FC<IProps> = ({}) => {
  const me = useSelector((state: AppState) => state.me);

  return <div>{me}</div>;
};

export default Test;
